import sqlite3 as sql

db = sql.connect('movie_details_db')

with db:
    cur = db.cursor()
    selectquery = "SELECT * FROM mymovies"
    cur.execute(selectquery)

    rows = cur.fetchall()

    for data in rows:
        print(data)