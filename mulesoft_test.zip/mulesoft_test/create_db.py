import sqlite3 as sql

def main():
   try:
       db = sql.connect('movie_details_db')
       print("Database created", db)

   except:
       print("failed to create database")
   db.commit()


if __name__ == "__main__":
      main()