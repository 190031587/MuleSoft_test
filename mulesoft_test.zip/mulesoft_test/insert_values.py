import sqlite3 as sql
details = (

    (1, 'Bahubali-1', 'Prabas', 'Anushka', 'Rajamouli',2011),
    (2, 'Bahubali-2','Prabas', 'Anushka', 'Rajamouli',2014),
    (3, 'RRR', 'Ram Charan', 'Alia Bhatt', 'Rajamouli',2022),

)
db = sql.connect('movie_details_db')


cur = db.cursor()
cur.executemany('INSERT INTO mymovies VALUES (?,?,?,?,?,?)', details)

print("Data Inserted Successfully")
db.commit()