import sqlite3 as sql

db = sql.connect('movie_details_db')

with db:
    cur = db.cursor()
    selectquery = "SELECT * FROM mymovies WHERE hero='Ram Charan'"
    cur.execute(selectquery)
    print(cur.fetchall())


